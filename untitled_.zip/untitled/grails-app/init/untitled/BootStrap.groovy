package untitled


import auth.*

import javax.servlet.http.HttpServletRequest


//class BootStrap {

//   def init = { servletContext ->
// }
//   def destroy = {
//   }


class BootStrap {
    def init = { servletContext ->
        HttpServletRequest.metaClass.isXhr = { ->
            'XMLHttpRequest' == delegate.getHeader('X-Requested-With')
        }
//
//        def currentDate = new Date()
//        def roleAdmin = Role.findByAuthority('ROLE_ADMIN') ?: new Role(authority: 'ROLE_ADMIN', description: 'System administrator', createdBy: 'admin', createdDate: currentDate).save(flush: true)
//        def user = User.findByUsername('admin') ?: new User(fullName: 'Administrator', username: 'admin', password: '123456', enabled: true, createdBy: 'admin', createdDate: currentDate).save(flush: true)
//        if (!user?.authorities?.contains(roleAdmin)) {
//            UserRole.create(user, roleAdmin, true)
//            // add some initial request map
//            for (String url in [
//                    '/index', '/index.gsp', '/shutdown', '/**/favicon.ico',
//                    '/assets/**', '/**/js/**', '/**/css/**', '/**/images/**',
//                    '/login', '/login.*', '/login/*',
//                    '/logout', '/logout.*', '/logout/*']) {
//                new Requestmap(url: url, configAttribute: 'permitAll', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            }
//            new Requestmap(url: '/', configAttribute: 'IS_AUTHENTICATED_FULLY', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/requestmap', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/requestmap/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/requestmap/*/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/role', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/role/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/role/*/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/user', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/user/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/user/*/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/menu', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/menu/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Requestmap(url: '/menu/*/*', configAttribute: 'ROLE_ADMIN', createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            // create some initial menus
//            new Menu(title: 'Home', description: 'Application home menu', urlPath: '/', menuType: 'MAIN_MENU', parentMenu: null, isActive: true, sortOrder: 1, createdDate: currentDate, createdBy: 'SYSTEM').save(flush: true)
//
//            def systemMenu = new Menu(title: 'System', description: 'Application administrative menu', urlPath: '/#System', menuType: 'MAIN_MENU', parentMenu: null, isActive: true, sortOrder: 2, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            // menu
//            def menuManage = new Menu(title: 'Manage Menu', description: 'Application menu manager', urlPath: '/#ManageMenu', menuType: 'MAIN_MENU', parentMenu: systemMenu, isActive: true, sortOrder: 1, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Menu(title: 'Create Menu', description: 'Create application menu', urlPath: '/menu/create', menuType: 'MAIN_MENU', parentMenu: menuManage, isActive: true, sortOrder: 1, createdDate: currentDate, createdBy: 'SYSTEM').save(flush: true)
//            new Menu(title: 'View Menu List', description: 'View application menu list', urlPath: '/menu/list', menuType: 'MAIN_MENU', parentMenu: menuManage, isActive: true, sortOrder: 2, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            // role
//            def roleManage = new Menu(title: 'Manage Role', description: 'Application role manager', urlPath: '/#ManageRole', menuType: 'MAIN_MENU', parentMenu: systemMenu, isActive: true, sortOrder: 2, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Menu(title: 'Create Role', description: 'Create application role', urlPath: '/role/create', menuType: 'MAIN_MENU', parentMenu: roleManage, isActive: true, sortOrder: 1, createdDate: currentDate, createdBy: 'SYSTEM').save(flush: true)
//            new Menu(title: 'View Role List', description: 'View application role list', urlPath: '/role/list', menuType: 'MAIN_MENU', parentMenu: roleManage, isActive: true, sortOrder: 2, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            // user
//            def userManage = new Menu(title: 'Manage User', description: 'Application user manager', urlPath: '/#ManageUser', menuType: 'MAIN_MENU', parentMenu: systemMenu, isActive: true, sortOrder: 3, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Menu(title: 'Create User', description: 'Create application user', urlPath: '/user/create', menuType: 'MAIN_MENU', parentMenu: userManage, isActive: true, sortOrder: 1, createdDate: currentDate, createdBy: 'SYSTEM').save(flush: true)
//            new Menu(title: 'View User List', description: 'View application user list', urlPath: '/user/list', menuType: 'MAIN_MENU', parentMenu: userManage, isActive: true, sortOrder: 2, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            // user permission
//            def permissionManage = new Menu(title: 'Manage Permission', description: 'Application permission manager', urlPath: '/#ManagePermission', menuType: 'MAIN_MENU', parentMenu: systemMenu, isActive: true, sortOrder: 4, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Menu(title: 'Create Permission', description: 'Create application permission', urlPath: '/requestmap/create', menuType: 'MAIN_MENU', parentMenu: permissionManage, isActive: true, sortOrder: 1, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            new Menu(title: 'View Permission List', description: 'View application permission list', urlPath: '/requestmap/list', menuType: 'MAIN_MENU', parentMenu: permissionManage, isActive: true, sortOrder: 2, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//            // logout
//            new Menu(title: 'Logout', description: 'Application logout menu', urlPath: '/logout', menuType: 'MAIN_MENU', parentMenu: null, isActive: true, sortOrder: 100, createdDate: currentDate, createdBy: 'admin').save(flush: true)
//        }
    }
    def destroy = {
    }
}


