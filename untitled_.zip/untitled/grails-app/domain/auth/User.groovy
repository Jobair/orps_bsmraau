package auth

import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import grails.compiler.GrailsCompileStatic

@GrailsCompileStatic
@EqualsAndHashCode(includes='username')
@ToString(includes='username', includeNames=true, includePackage=false)
class User implements Serializable {

    private static final long serialVersionUID = 1

    String fullName
    String username
    String password
    boolean enabled = true
    boolean accountExpired
    boolean accountLocked
    boolean passwordExpired
    String createdBy
    Date createdDate
    String modifiedBy
    Date modifiedDate

    Set<Role> getAuthorities() {
        (UserRole.findAllByUser(this) as List<UserRole>)*.role as Set<Role>
    }

    static constraints = {
        fullName nullable: false
        password nullable: false, blank: false, password: true
        username nullable: false, blank: false, unique: true
        enabled nullable: false
        accountExpired nullable: false
        accountLocked nullable: false
        passwordExpired nullable: false
        createdBy nullable: false
        createdDate nullable: false
        modifiedBy nullable: true
        modifiedDate nullable: true
    }

    String toString() {
        return username
    }

    static mapping = {
        table 'auth_users'
        id column: 'id', params: [sequence: 'auth_users_seq'] // only for oracle db
        version false
        password column: '`password`'
    }
}
