var baseUrl=$("body").attr("baseurl");
function rowAdd(tableId) {
    $("#" + tableId).append(
        '<tr valign="top">' +
        '<td><div class="form-group"><input type="file" name="attachment"></div></td>' +
        '<td><a href="javascript:void(0);"  onclick="rowRemove(this)"><i class="fa fa-fw fa-trash-o"></i></a></td>' +
        '</tr>'
    );
}

function rowRemove(e) {
    e.parentElement.parentElement.remove();
}

// --For Purchase re--
function itemRowAdd(tableId) {
    var rowID = $("#" + tableId + " tr.itemRow:last input.prItem").attr("id").split('prItem_');
    rowsize = 1 + parseInt(rowID[1]);

    var html = '<tr valign="top" class="itemRow">';
    html += '<td> <input type="text" class="prItem form-control" name="na" required="required" onkeyup="getItemList(' + rowsize + ')" id="prItem_' + rowsize + '" value="" />';
    html += '<input type="hidden" name="detail.'+rowsize+'.lineNo" value="' + rowsize + '"></td>';
    html += '<input type="hidden" name="detail.forLooping" value="0"></td>';
    html += '<input type="hidden" class="prItemId" name="detail.'+rowsize+'.item" id="prItemId_' + rowsize + '" value=""></td>';
    html += '<td><input type="hidden" name="detail.'+rowsize+'.description" id="description_' + rowsize + '"><input type="text" name="detail.'+rowsize+'.specification" class="form-control"></td>';
    html += '<td id="itemMinQty_'+rowsize+'"> </td>';
    html += '<td id="itemRequestUOM_'+rowsize+'"> </td>';
    html += '<td><input type="text" name="detail.'+rowsize+'.requisitionQty" required="required" onkeyup="itemMinQty(' + rowsize + ')" id="prattr_' + rowsize + '"  class="form-control requisitionQty"> </td>';
    html += '<td><a class="btn btn-primary btn-xs" href="javascript:void(0);" onclick="itemRowAdd(' + "'itemAddMore'" + ')"> <i class="fa fa-plus"></i>Add</a> <a href="javascript:void(0);" class="btn btn-danger btn-xs" onclick="rowRemove(this)"><i class="fa fa-fw fa-trash-o"></i>Trash</a></td>';
    html += '</tr>';
    $("#" + tableId).append(html);
}

function getItemList(rowsize) {

    $("#prItem_" + rowsize).autocomplete({
        source: baseUrl+"/CommonAjax/getItemList",
        minLength: 3,
        select: function (event, ui) {
            $("#prItemId_" + rowsize).val(ui.item.id);
            $("#description_" + rowsize).val(ui.item.description);
            $("#itemMinQty_" + rowsize).text(ui.item.itemMinQty);
            $("#itemRequestUOM_" + rowsize).text(ui.item.uom);
            $("#uomId_" + rowsize).val(ui.item.uomId);
            $("#prattr_" + rowsize).attr({'uomAtt':ui.item.attribute});

            var itemId = ui.item.id;
            var priceMasterId = parseInt($("#priceMaster").val());
            var itemClass = $(".dd").val();
            if(itemClass){
                if(!priceMasterId){
                    alert("Please Select Price Master");
                    return false;
                }

                $.ajax({
                    type: "POST",
                    url: baseUrl+"/CommonAjax/getItemPrice",
                    dataType: 'JSON',
                    data: {
                        itemId: itemId,priceMasterId:priceMasterId
                    },
                    success: function (response) {
                        if(response.itemPrice){
                            $("#rate_" + rowsize).val(response.itemPrice);
                        }
                        else{
                            alert("Please Set an Item Price");
                        }


                    },
                    error: function (err) {
                        alert(err);
                    }
                });

            }

        }
    });
}

function itemRowAdd1(tableId) {
    var rowID = $("#" + tableId + " tr.itemRow:last input.prItem").attr("id").split('prItem_');
    rowsize = 1 + parseInt(rowID[1]);

    var html = '<tr valign="top" class="itemRow">';
    html += '<td><input type="text" class="prItem form-control" name="na" required="required" onkeyup="getItemList(' + rowsize + ')" id="prItem_' + rowsize + '" value="" />';
    html += '<input type="hidden" name="detail.'+rowsize+'.lineNo" value="' + rowsize + '"></td>';
    html += '<input type="hidden" name="detail.forLooping" value="0"></td>';
    html += '<input type="hidden" name="detail.'+rowsize+'.uom" id="uomId_' + rowsize + '" value=""></td>';
    // html += '<input type="hidden" name="detail.'+rowsize+'.uom" value="' + rowsize + '"></td>';
    html += '<input type="hidden" class="prItemId" name="detail.'+rowsize+'.item" id="prItemId_' + rowsize + '" value=""></td>';
    html += '<td><input type="text" class="quantity form-control" required="required" name="detail.'+rowsize+'.quantity" id="quantity_' + rowsize + '" value=""></td>';
    html += '<td id="itemRequestUOM_'+rowsize+'"></td>';
    html += '<td><input type="text" class="rate form-control" required="required" name="detail.'+rowsize+'.rate" id="rate_' + rowsize + '" value=""></td>';
    html += '<td><input type="text" class="subTotal form-control" required="required" name="detail.'+rowsize+'.subTotal" id="subTotal_' + rowsize + '" value=""></td>';
    html += '<td><input type="text" class="rebate form-control" required="required" name="detail.'+rowsize+'.rebate" id="rebate_' + rowsize + '" value=""></td>';
    html += '<td><input type="text" class="taxAmount form-control" required="required" name="detail.'+rowsize+'.taxAmount" id="taxAmount_' + rowsize + '" value=""></td>';
    html += '<td><input type="text" class="netTotal form-control" required="required" name="detail.'+rowsize+'.netTotal" id="netTotal_' + rowsize + '" value=""></td>';
    html += '<td><input type="text" class="purchaseValue form-control" required="required" name="detail.'+rowsize+'.purchaseValue" id="purchaseValue_' + rowsize + '" value=""></td>';
    html += '<td><input type="text" class="mrpValue form-control" required="required" name="detail.'+rowsize+'.mrpValue" id="mrpValue_' + rowsize + '" value=""></td>';
    html += '<td><a class="btn btn-primary btn-xs" href="javascript:void(0);" onclick="itemRowAdd1(' + "'itemAddMore'" + ')"> <i class="fa fa-plus"></i>Add</a> <a href="javascript:void(0);" class="btn btn-danger btn-xs" onclick="rowRemove(this)"><i class="fa fa-fw fa-trash-o"></i>Trash</a></td>';
    html += '</tr>';
    $("#" + tableId).append(html);
}


function getItemOrderList(rowsize){
    var masterId = parseInt($("#priceMaster").val());
    alert(masterId);
    var itemId = $("#prItem_" + rowsize).val();
    alert(itemId);

}

function itemMinQty(rowsize) {
    var requQty = parseInt($("#prattr_" + rowsize).val());
    var minQty = parseInt($("#itemMinQty_" + rowsize).text());
    if(requQty<minQty){
        $("#prattr_" + rowsize).val(minQty);
        alert("Requisition Qty must be equal or greater than" + " " + minQty);
    }
}

function getItemGroup(optvalue){
    $.ajax({
        type: "POST",
        url: baseUrl+"/CommonAjax/getItemGroup",
        dataType: 'JSON',
        data: {
            groupId: optvalue
        },
        success: function (response) {
            $("#itemType option[value="+response.mapList.itemTypeId+"]").attr('selected', 'selected');
            $("#select2-itemType-container").text(response.mapList.itemTypeName);
            // console.log(response.itemGroupObj.isAssetItem);
            if(response.itemGroupObj.isPurchaseItem == true) {
                $("#isPurchaseItem").attr('checked', 'checked');
                $("#purchaseCheck .icheckbox_minimal-blue").addClass("checked");
                $("#purchaseCheck .icheckbox_minimal-blue").attr("aria-checked", true);
            }
            $("#minPurchaseQty").val(response.itemGroupObj.minPurchaseQty);
            $("#purchaseUom option[value="+response.mapList.purchaseUomId+"]").attr('selected', 'selected');
            $("#select2-purchaseUom-container").text(response.mapList.purchaseUomName);
            $("#orderInterval").val(response.itemGroupObj.orderInterval);
            $("#leadTime").val(response.itemGroupObj.leadTime);
            $("#supplier option[value="+response.mapList.supplierId+"]").attr('selected', 'selected');
            $("#select2-supplier-container").text(response.mapList.supplierName);
            // $("#isAssetItem").checkbox(response.itemGroupObj.isAssetItem);
            if(response.itemGroupObj.isAssetItem == true) {
                $("#isAssetItem").attr('checked', 'checked');
                $("#invenCheck .icheckbox_minimal-blue").addClass("checked");
                $("#invenCheck .icheckbox_minimal-blue").attr("aria-checked", true);
            }
            if(response.itemGroupObj.isInventoryItem == true) {
                $("#isInventoryItem").attr('checked', 'checked');
                $("#isInventorycheck .icheckbox_minimal-blue").addClass("checked");
                $("#isInventorycheck .icheckbox_minimal-blue").attr("aria-checked", true);
            }
            $("#height").val(response.itemGroupObj.height);
            $("#width").val(response.itemGroupObj.width);
            $("#length").val(response.itemGroupObj.length);
            $("#lengthUom option[value="+response.mapList.lengthUomId+"]").attr('selected', 'selected');
            $("#select2-lengthUom-container").text(response.mapList.lengthUomName);
            $("#weight").val(response.itemGroupObj.weight);
            $("#weightUom option[value="+response.mapList.weightUomId+"]").attr('selected', 'selected');
            $("#select2-weightUom-container").text(response.mapList.weightUomName);
            $("#volume").val(response.itemGroupObj.volume);
            $("#volumeUom option[value="+response.mapList.volumeUomId+"]").attr('selected', 'selected');
            $("#select2-volumeUom-container").text(response.mapList.volumeUomName);
            $("#uom option[value="+response.mapList.uomId+"]").attr('selected', 'selected');
            $("#select2-uom-container").text(response.mapList.uomName);
            if(response.itemGroupObj.isSalesItem == true) {
                $("#isSalesItem").attr('checked', 'checked');
                $("#salesCheck .icheckbox_minimal-blue").addClass("checked");
                $("#salesCheck .icheckbox_minimal-blue").attr("aria-checked", true);
            }
            $("#minSalesQty").val(response.itemGroupObj.minSalesQty);
            $("#salesUom option[value="+response.mapList.salesUomId+"]").attr('selected', 'selected');
            $("#select2-salesUom-container").text(response.mapList.salesUomName);
            $("#stdCost").val(response.itemGroupObj.stdCost);
            $("#numOfComponents").val(response.itemGroupObj.numOfComponents);
            $("#numOfResources").val(response.itemGroupObj.numOfResources);
            $("#purchaseTaxClass option[value="+response.mapList.purchaseTaxClassId+"]").attr('selected', 'selected');
            $("#select2-purchaseTaxClass-container").text(response.mapList.purchaseTaxClassName);
            $("#salesTaxClass option[value="+response.mapList.salesTaxClassId+"]").attr('selected', 'selected');
            $("#select2-salesTaxClass-container").text(response.mapList.salesTaxClassName);
            $("#store_0 option[value="+response.mapList.defaultStoreId+"]").attr('selected', 'selected');
            $("#store_0").val(response.mapList.defaultStoreName);
            $("#storeId_0").val(response.mapList.defaultStoreId);
            $("#weight").val(response.itemGroupObj.weight);
            $("#weightUom option[value="+response.mapList.weightUomId+"]").attr('selected', 'selected');
            $("#select2-weightUom-container").text(response.mapList.weightUomName);
        },
        error: function (err) {
            alert(err);
        }
    });

}

function getOrganizationList(selectID, resultID, prefix) {
    $("#" + selectID + prefix).autocomplete({
        source: baseUrl+"/CommonAjax/getOrganization",
        minLength: 3,
        select: function (event, ui) {
            $("#" + resultID + prefix).val(ui.item.id);

        }
    });
}


function getSupplier(selectID, resultID, prefix) {

    $("#" + selectID + prefix).autocomplete({
        source: baseUrl+"/CommonAjax/getSupplier",
        minLength: 3,
        select: function (event, ui) {
            $("#" + resultID + prefix).val(ui.item.id);
        }
    });
}

$("#getOrganization").autocomplete({
    // source: baseUrl+"/CommonAjax/getOrganization",
    source: baseUrl+"/CommonAjax/getOrganization",
    minLength: 3,
    select: function (event, ui) {
        $("#prOrgId").val(ui.item.id);
    }
});

$("#getCustomer").autocomplete({
    // source: baseUrl+"/CommonAjax/getOrganization",
    source: baseUrl+"/CommonAjax/getCustomer",
    minLength: 3,
    select: function (event, ui) {
        $("#custId").val(ui.item.id);
    }
});


// $("#getSupplier").autocomplete({
//     source: baseUrl+"/CommonAjax/getSupplier",
//     minLength: 3,
//     select: function (event, ui) {
//         $("#poSupplier").val(ui.item.id);
//     }
// });

function getProcessList(rowsize) {
    $("#prProcess_" + rowsize).autocomplete({
        source: baseUrl+"/CommonAjax/getProcessList",
        minLength: 3,
        select: function (event, ui) {
            $("#prProcessId_" + rowsize).val(ui.process.id);
            // $("#description_"+rowsize).val(ui.item.description);
        }
    });
}

$("#approvalProcess").autocomplete({
    source: baseUrl+"/CommonAjax/getApprovalProcess",
    minLength: 3,
    select: function (event, ui) {
        $("#prApprovalProcess").val(ui.item.id);
    }
});

$("#processKeyword").autocomplete({
    source: baseUrl+"/CommonAjax/getProcessKeyword",
    minLength: 3,
    select: function (event, ui) {
        $("#prProcessKeyword").val(ui.item.id);
    }
});

$("#approvalGroup").autocomplete({
    source: baseUrl+"/CommonAjax/getApprovalGroup",
    minLength: 3,
    select: function (event, ui) {
        $("#prApprovalGroup").val(ui.item.id);
    }
});
$("#getMember").autocomplete({
    source: baseUrl+"/CommonAjax/getApprovalMember",
    minLength: 3,
    select: function (event, ui) {
        $("#groupUserId").val(ui.item.id);
    }
});


$("#bankName").autocomplete({
    source: baseUrl+"/CommonAjax/getBankList",
    minLength: 3,
    select: function (event, ui) {
        $("#bankNameId").val(ui.item.id);
    }
});

function QtyCheckAndSum(appQty, itemID, reQty, minQty) {
    if (checkNumericValue(appQty) == 1) {
        alert("Please enter numeric value!");
        $("#reQty_" + itemID).val("");
    }
    // if (appQty > reQty) {
    //     alert("Maximum quantity " + reQty);
    //     $("#reQty_" + itemID).val(reQty);
    // }

    if(appQty<minQty || appQty>reQty){
        if (appQty > reQty) {
            alert("Maximum quantity " + reQty);
            $("#reQty_" + itemID).val(reQty);
        }
        else{
            alert("Minimum quantity " + minQty);
            $("#reQty_" + itemID).val(minQty);
        }
    }
//        console.log();
    $("#totalRecommendedQty").text(qtySum('approvedQty'));
}

function checkNumericValue(nValue) {
    if (!/^[0-9]+$/.test(nValue.trim())) {
        return 1;
    } else {
        return 0;
    }
}

function qtySum(divClass) {
    var total = 0;
    $("." + divClass).each(function () {
        total = total + Number(this.value);
    });
    return total
}

function lowerCheck(itemID) {
    var thisVal = $("#ordQty_" + itemID).val();
    if (checkNumericValue(thisVal) == 1) {
        alert("Please enter numeric value!");
        $("#ordQty_" + itemID).val("");
    }
    var remQty = Number($("#rem" + itemID).text());
    if (thisVal > remQty) {
        alert("Maximum quantity " + remQty);
        $("#ordQty_" + itemID).val(remQty);
    }
    //unitPriceCalculation(itemID,'ordQty_','unitPrice_','totalPrice_');

}
function unitPriceCalculation (reAndItemID,QtyPrefix,uPricePrefix,tPricePrefix) {
    //29181,'ordQty_','unitPrice_','totalPrice_'
    var ordQty = Number($("#"+QtyPrefix + reAndItemID).val());
    var unitPrice = Number($("#"+uPricePrefix + reAndItemID).val());
    if(ordQty==''){
        alert("Please enter valid order Qty");
    }
    if(isNaN(unitPrice)){
        alert("Please enter valid price");

    }
    var totalPrice = parseFloat(ordQty*unitPrice);
    $("#"+tPricePrefix + reAndItemID).val(totalPrice.toFixed(2));
}
function lowerValueCheck(qtyId,lessthenId) {
    var value1=$("#"+qtyId).val();
    var value2=$("#"+lessthenId).val();
    if(value1<=value2){
        return 0;
    }else{
        return 1;
    }

}
function itemQtyCheckAndSum(itemID,ordQtyID,ordRateID,appvdQtyID,appvdRateID,appvdAmountID) {
    var appvdQty,ordQty,ordRate,appvdRate,appvdAmount,totalAppvdQty,totalAppvdAmount;

    appvdQty=$("#"+appvdQtyID+"_"+itemID).val();
    ordQty=$("#"+ordQtyID+"_"+itemID).text();
    ordRate=$("#"+ordRateID+"_"+itemID).text();
    appvdRate=parseFloat($("#"+appvdRateID+"_"+itemID).val());

    if (checkNumericValue(appvdQty) == 1) {
        $("#"+appvdQtyID+"_"+itemID).val(" ");
        alert("Please enter numeric value for appvd.Qty!");
    }
    if(ordQty<Number(appvdQty)){
        alert("You are trying maximum quantity " + ordQty);
        $("#"+appvdQtyID+"_"+itemID).val(ordQty);
        appvdQty=ordQty;

    }
    if(isNaN(appvdRate) || appvdRate==0){
        $("#"+appvdRateID+"_"+itemID).val("0");
    }

    if(ordRate<appvdRate){
        alert("You are trying maximum rate  " + ordRate);
        $("#"+appvdRateID+"_"+itemID).val(ordRate);
        appvdRate=ordRate
    }
    appvdAmount=parseFloat(appvdQty*appvdRate).toFixed(2);
    $("#"+appvdAmountID+"_"+itemID).val(appvdAmount);

    totalAppvdQty=qtySum('approvedQty');
    $("#totalApproveQty").text(totalAppvdQty);

    totalAppvdAmount=parseFloat(qtySum('appvdAmount')).toFixed(2);
    $("#totalApproveAmount").text(totalAppvdAmount);


}

function getStoreList(rowsize,orgId) {

    var org=parseInt($("#"+orgId).val());
    var url=baseUrl+"/CommonAjax/getStoreList";
    if(isNaN(org)){

    }else{
        url+="?orgId="+org;

    }
// alert(url);
    $("#store_" + rowsize).autocomplete({
        source: url,
        minLength: 3,
        select: function (event, ui) {
            $("#storeId_" + rowsize).val(ui.item.id);
            // $("#description_" + rowsize).val(ui.item.description);

        }
    });
}



