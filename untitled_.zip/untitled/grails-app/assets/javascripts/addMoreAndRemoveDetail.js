(function($){
    $.fn.addMore=function (selectorClass,fieldsTypeArray){
        var selectorIndex = $("." + selectorClass).length;
        var cloneElement = "." + selectorClass + ":last";
        var removeBtn = '<a class="btn btn-danger btn-xs" onclick="removeDetail(\'' + selectorClass + '\', this);"><i class="fa fa-fw fa-trash-o"></i>Trash</a>';
        // console.log($(cloneElement).clone().show());
        // var htmlData=$(cloneElement).clone(true).html().replace(/\d+/, selectorIndex);
        // console.log(htmlData);
        // $(cloneElement).clone().insertAfter(cloneElement);
        $(cloneElement).clone(true).insertAfter(cloneElement).replace(/\d+/,selectorIndex);
        // $(cloneElement).clone(true)
        //     // .replace(/\d+/, selectorIndex)
        //     .insertAfter(cloneElement)
        //     .find("*")
        //     .each(function () {
        //         var id = this.id || "";
        //         var name = this.name || "";
        //         if(id!=""){
        //             this.id = id.replace(/\d+/, selectorIndex);
        //             this.name = name.replace(/\d+/, selectorIndex);
        //
        //         }
        //     });


        if ($(cloneElement + " > .box-footer").length == 0) {
            $(cloneElement + " > .box-body").html(removeBtn);
        }

        if(Array.isArray(fieldsTypeArray)){
            for (var i = 0; i < fieldsTypeArray.length; i++) {
                $(cloneElement).find(fieldsTypeArray[i]).val('');
            }
        }

        selectorIndex++;
        return true;
    };
    $.fn.removeInfo=function (removeElementClass, _this){
        var removeElement = "." + removeElementClass;
        $(_this).closest(removeElement).remove();
        $(removeElement).each(function (i, obj) {
            $(obj).find("*")
                .each(function (j, elem) {
                    var id = this.id || "";
                    var name = this.name || "";
                    if(id!=""){
                        this.id = id.replace(/\d+/, i);
                        this.name = name.replace(/\d+/, i);
                    }
                });
        });
        return true;
    };
}(jQuery));


//plugin call
$(".addMoreRow").click(function () {
    $(this).addMore('itemRow',['input','textarea']);
});
function removeDetail(removeElementClass, _this) {
    $(this).removeInfo(removeElementClass, _this);
}





