package auth

class MenuTagLib {
    //static defaultEncodeAs = [taglib:'html']
    static namespace = "menu"
    MenuService menuService
    def loadMenu = { attr ->
        out << menuService.getMenu(attr.type)
    }
}
