package report

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class ReportControllerSpec extends Specification implements ControllerUnitTest<ReportController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
