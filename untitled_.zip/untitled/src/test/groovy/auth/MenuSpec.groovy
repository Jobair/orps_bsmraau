package auth

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class MenuSpec extends Specification implements DomainUnitTest<Menu> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
